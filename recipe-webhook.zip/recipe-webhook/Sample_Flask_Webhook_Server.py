from flask import Flask, request, jsonify
import requests
import os
from clarifai_grpc.channel.clarifai_channel import ClarifaiChannel
from clarifai_grpc.grpc.api import service_pb2, service_pb2_grpc
from clarifai_grpc.grpc.api import resources_pb2
from clarifai_grpc.grpc.api.status import status_code_pb2
import base64

app = Flask(__name__)

CLARIFAI_API_KEY = "4a4ea9088cfa42c29e63f7b6806ad272"
SPOONACULAR_API_KEY = "b97364cb57314c0fb18b8d7e93d7e5fc"

channel = ClarifaiChannel.get_grpc_channel()
stub = service_pb2_grpc.V2Stub(channel)
metadata = (("authorization", f"Key {CLARIFAI_API_KEY}"),)

UNWANTED_WORDS = {"pasture", "micronutrient", "aliment", "comestible"}
CONFIDENCE_THRESHOLD = 0.5


def recognize_ingredients_from_base64(base64_image):
    request = service_pb2.PostModelOutputsRequest(
        model_id="food-item-v1-recognition",
        inputs=[
            resources_pb2.Input(
                data=resources_pb2.Data(
                    image=resources_pb2.Image(base64=base64.b64decode(base64_image))
                )
            )
        ]
    )
    response = stub.PostModelOutputs(request, metadata=metadata)

    if response.status.code != status_code_pb2.SUCCESS:
        return []

    filtered_ingredients = []
    for concept in response.outputs[0].data.concepts:
        if concept.value >= CONFIDENCE_THRESHOLD and concept.name.lower() not in UNWANTED_WORDS:
            filtered_ingredients.append(concept.name.lower())

    return filtered_ingredients


def get_recipe_details(recipe_id):
    url = f"https://api.spoonacular.com/recipes/{recipe_id}/information?apiKey={SPOONACULAR_API_KEY}"
    response = requests.get(url)
    if response.status_code == 200:
        recipe_data = response.json()
        return {
            "title": recipe_data.get("title"),
            "sourceUrl": recipe_data.get("sourceUrl", "No URL Available")
        }
    return None


def get_recipes(ingredients):
    ingredients_query = ",".join(ingredients)
    url = f"https://api.spoonacular.com/recipes/findByIngredients?ingredients={ingredients_query}&number=5&apiKey={SPOONACULAR_API_KEY}"
    response = requests.get(url)
    if response.status_code != 200:
        return []

    recipes = response.json()
    return [get_recipe_details(recipe["id"]) for recipe in recipes if recipe.get("id")]


@app.route("/webhook", methods=["POST"])
def webhook():
    req = request.get_json()

    intent = req["queryResult"]["intent"]["displayName"]
    parameters = req["queryResult"].get("parameters", {})

    if intent == "UploadImageIntent":
        base64_image = parameters.get("imageBase64")
        ingredients = recognize_ingredients_from_base64(base64_image)
        return jsonify({
            "fulfillmentText": f"I found these ingredients: {', '.join(ingredients)}. Want to see recipes?"
        })

    elif intent == "GetRecipesIntent":
        ingredients = parameters.get("ingredients", [])
        recipes = get_recipes(ingredients)
        if recipes:
            response_text = "\n".join([f"{r['title']} - {r['sourceUrl']}" for r in recipes])
        else:
            response_text = "Sorry, I couldn't find any recipes with those ingredients."

        return jsonify({"fulfillmentText": response_text})

    return jsonify({"fulfillmentText": "Sorry, I didn’t understand that."})


if __name__ == "__main__":
    app.run(port=5000)
